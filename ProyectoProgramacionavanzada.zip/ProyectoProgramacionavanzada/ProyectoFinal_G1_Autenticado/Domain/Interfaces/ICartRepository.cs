using System.Collections.Generic;
using System.Threading.Tasks;
using ProyectoFinal_G1_Autenticado.Models;

namespace ProyectoFinal_G1_Autenticado.Domain.Interfaces
{
    public interface ICartRepository
    {
        Task<IEnumerable<CartItem>> GetByUserAsync(string userId);
        Task AddAsync(CartItem item);
        Task DeleteAsync(int id);
        Task ClearCartForUserAsync(string userId);
    }
}
