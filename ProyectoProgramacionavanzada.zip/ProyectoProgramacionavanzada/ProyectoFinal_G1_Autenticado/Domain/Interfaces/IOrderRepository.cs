using System.Collections.Generic;
using System.Threading.Tasks;
using ProyectoFinal_G1_Autenticado.Models;

namespace ProyectoFinal_G1_Autenticado.Domain.Interfaces
{
    public interface IOrderRepository
    {
        Task<Order> GetByIdAsync(int id);
        Task<IEnumerable<Order>> GetByUserAsync(string userId);
        Task AddAsync(Order order);
    }
}
