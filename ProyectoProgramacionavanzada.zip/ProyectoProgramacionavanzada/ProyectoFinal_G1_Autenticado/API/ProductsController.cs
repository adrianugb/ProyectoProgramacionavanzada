using System.Threading.Tasks;
using System.Web.Http;
using ProyectoFinal_G1_Autenticado.Services;
using ProyectoFinal_G1_Autenticado.Models;

namespace ProyectoFinal_G1_Autenticado.API
{
    [RoutePrefix("api/products")]
    public class ProductsController : ApiController
    {
        private readonly ProductService _service;
        public ProductsController(ProductService service) { _service = service; }

        [HttpGet, Route("")]
        public async Task<IHttpActionResult> GetAll()
        {
            var items = await _service.GetAllAsync();
            return Ok(items);
        }

        [HttpGet, Route("{id:int}")]
        public async Task<IHttpActionResult> Get(int id)
        {
            var item = await _service.GetByIdAsync(id);
            if (item == null) return NotFound();
            return Ok(item);
        }

        [HttpPost, Route("")]
        public async Task<IHttpActionResult> Create(Product model)
        {
            await _service.AddAsync(model);
            return Ok(model);
        }

        [HttpPut, Route("{id:int}")]
        public async Task<IHttpActionResult> Update(int id, Product model)
        {
            if (model.ProductId != id) return BadRequest();
            await _service.UpdateAsync(model);
            return Ok(model);
        }

        [HttpDelete, Route("{id:int}")]
        public async Task<IHttpActionResult> Delete(int id)
        {
            await _service.DeleteAsync(id);
            return Ok();
        }
    }
}
