using System.Threading.Tasks;
using System.Web.Http;
using ProyectoFinal_G1_Autenticado.Services;
using ProyectoFinal_G1_Autenticado.Models;

namespace ProyectoFinal_G1_Autenticado.API
{
    [RoutePrefix("api/cart")]
    public class CartController : ApiController
    {
        private readonly CartService _service;
        public CartController(CartService service) { _service = service; }

        [HttpGet, Route("{userId}")]
        public async Task<IHttpActionResult> GetCart(string userId)
        {
            var items = await _service.GetByUserAsync(userId);
            return Ok(items);
        }

        [HttpPost, Route("")]
        public async Task<IHttpActionResult> AddItem(CartItem item)
        {
            await _service.AddAsync(item);
            return Ok(item);
        }

        [HttpDelete, Route("{id:int}")]
        public async Task<IHttpActionResult> RemoveItem(int id)
        {
            await _service.DeleteAsync(id);
            return Ok();
        }
    }
}
