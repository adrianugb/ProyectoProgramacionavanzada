using System.Threading.Tasks;
using System.Web.Http;
using ProyectoFinal_G1_Autenticado.Services;
using ProyectoFinal_G1_Autenticado.Models;

namespace ProyectoFinal_G1_Autenticado.API
{
    [RoutePrefix("api/reviews")]
    public class ReviewsController : ApiController
    {
        private readonly ReviewService _service;
        public ReviewsController(ReviewService service) { _service = service; }

        [HttpGet, Route("product/{productId:int}")]
        public async Task<IHttpActionResult> GetByProduct(int productId)
        {
            var items = await _service.GetByProductAsync(productId);
            return Ok(items);
        }

        [HttpPost, Route("")]
        public async Task<IHttpActionResult> Create(Review model)
        {
            await _service.AddAsync(model);
            return Ok(model);
        }

        [HttpPut, Route("{id:int}")]
        public async Task<IHttpActionResult> Update(int id, Review model)
        {
            if (id != model.Id) return BadRequest();
            await _service.UpdateAsync(model);
            return Ok(model);
        }
    }
}
