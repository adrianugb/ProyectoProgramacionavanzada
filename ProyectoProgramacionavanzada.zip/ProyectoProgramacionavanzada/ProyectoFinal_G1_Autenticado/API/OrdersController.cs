using System.Threading.Tasks;
using System.Web.Http;
using ProyectoFinal_G1_Autenticado.Services;
using ProyectoFinal_G1_Autenticado.Models;

namespace ProyectoFinal_G1_Autenticado.API
{
    [RoutePrefix("api/orders")]
    public class OrdersController : ApiController
    {
        private readonly OrderService _service;
        public OrdersController(OrderService service) { _service = service; }

        [HttpGet, Route("{id:int}")]
        public async Task<IHttpActionResult> Get(int id)
        {
            var order = await _service.GetByIdAsync(id);
            if (order == null) return NotFound();
            return Ok(order);
        }

        [HttpGet, Route("user/{userId}")]
        public async Task<IHttpActionResult> GetByUser(string userId)
        {
            var list = await _service.GetByUserAsync(userId);
            return Ok(list);
        }

        [HttpPost, Route("")]
        public async Task<IHttpActionResult> Create(Order order)
        {
            await _service.AddAsync(order);
            return Ok(order);
        }
    }
}
