Capas Domain/Interfaces, Repositories, Services y API generadas y listas para usar.
