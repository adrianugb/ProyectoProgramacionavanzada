using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using ProyectoFinal_G1_Autenticado.Domain.Interfaces;
using ProyectoFinal_G1_Autenticado.Models;

namespace ProyectoFinal_G1_Autenticado.Repositories
{
    public class ReviewRepository : IReviewRepository
    {
        private readonly ApplicationDbContext _context;
        public ReviewRepository(ApplicationDbContext context) { _context = context; }

        public async Task<IEnumerable<Review>> GetByProductIdAsync(int productId)
        {
            return await _context.Reviews
                .Where(r => r.ProductId == productId && r.Status == ReviewStatus.Aprobado)
                .ToListAsync();
        }

        public async Task<Review> GetByIdAsync(int id)
        {
            return await _context.Reviews.FindAsync(id);
        }

        public async Task AddAsync(Review entity)
        {
            _context.Reviews.Add(entity);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(Review entity)
        {
            _context.Entry(entity).State = EntityState.Modified;
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var e = await _context.Reviews.FindAsync(id);
            if (e != null)
            {
                _context.Reviews.Remove(e);
                await _context.SaveChangesAsync();
            }
        }
    }
}
