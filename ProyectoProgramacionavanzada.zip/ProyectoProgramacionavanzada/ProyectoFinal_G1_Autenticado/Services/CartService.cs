using System.Collections.Generic;
using System.Threading.Tasks;
using ProyectoFinal_G1_Autenticado.Domain.Interfaces;
using ProyectoFinal_G1_Autenticado.Models;

namespace ProyectoFinal_G1_Autenticado.Services
{
    public class CartService
    {
        private readonly ICartRepository _repo;
        public CartService(ICartRepository repo) { _repo = repo; }

        public Task<IEnumerable<CartItem>> GetByUserAsync(string userId) => _repo.GetByUserAsync(userId);
        public Task AddAsync(CartItem item) => _repo.AddAsync(item);
        public Task DeleteAsync(int id) => _repo.DeleteAsync(id);
        public Task ClearCartForUserAsync(string userId) => _repo.ClearCartForUserAsync(userId);
    }
}
