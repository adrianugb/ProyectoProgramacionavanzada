using System.Collections.Generic;
using System.Threading.Tasks;
using ProyectoFinal_G1_Autenticado.Domain.Interfaces;
using ProyectoFinal_G1_Autenticado.Models;

namespace ProyectoFinal_G1_Autenticado.Services
{
    public class ReviewService
    {
        private readonly IReviewRepository _repo;
        public ReviewService(IReviewRepository repo) { _repo = repo; }

        public Task<IEnumerable<Review>> GetByProductAsync(int productId) => _repo.GetByProductIdAsync(productId);
        public Task<Review> GetByIdAsync(int id) => _repo.GetByIdAsync(id);
        public Task AddAsync(Review r) => _repo.AddAsync(r);
        public Task UpdateAsync(Review r) => _repo.UpdateAsync(r);
        public Task DeleteAsync(int id) => _repo.DeleteAsync(id);
    }
}
