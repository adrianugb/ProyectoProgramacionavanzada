using System.Threading.Tasks;
using System.Collections.Generic;
using ProyectoFinal_G1_Autenticado.Domain.Interfaces;
using ProyectoFinal_G1_Autenticado.Models;

namespace ProyectoFinal_G1_Autenticado.Services
{
    public class OrderService
    {
        private readonly IOrderRepository _repo;
        public OrderService(IOrderRepository repo) { _repo = repo; }

        public Task<Order> GetByIdAsync(int id) => _repo.GetByIdAsync(id);
        public Task<IEnumerable<Order>> GetByUserAsync(string userId) => _repo.GetByUserAsync(userId);
        public Task AddAsync(Order order) => _repo.AddAsync(order);
    }
}
