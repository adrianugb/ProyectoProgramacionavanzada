Services layer placeholder.
