Domain layer placeholder.
