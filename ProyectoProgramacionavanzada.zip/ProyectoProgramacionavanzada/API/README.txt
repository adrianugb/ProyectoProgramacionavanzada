API layer placeholder.
