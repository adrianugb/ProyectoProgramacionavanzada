Repositories layer placeholder.
